#include "HelloWorldScene.h"
#include "MyDefine.h"
USING_NS_CC;
#define SCALE_RATIO 32.0
Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    this->setColor(cocos2d::Color3B(0,255,0));
    visibleSize = Director::getInstance()->getVisibleSize();
    Vec2 origin = Director::getInstance()->getVisibleOrigin();

    /////////////////////////////
    // 2. add a menu item with "X" image, which is clicked to quit the program
    //    you may modify it.

    // add a "close" icon to exit the progress. it's an autorelease object

    cocos2d::Sprite * bg = cocos2d::Sprite::create("Floor.png");
    bg->setAnchorPoint(cocos2d::Point(0,0));
    bg->setScaleX(visibleSize.width / bg->getContentSize().width);
    bg->setScaleY(visibleSize.height / bg->getContentSize().height);
    this->addChild(bg, -1);
    /////////////////////////////
    // 3. add your codes below...
    wallRight = Sprite::create("Wall.png");
    wallRight->setTag(2);
    wallRight->setPosition(visibleSize.width, visibleSize.height/2);
    this->addChild(wallRight, 0);
    _background = MyParallax::create();
    //Add Wall
    {
        unsigned int _wall = 4;
        _background->setNumberWall(_wall);
        for (unsigned int i = 0; i < _wall; i++)
        {
            cocos2d::Sprite * _node_left = cocos2d::Sprite::create("Wall.png");
            cocos2d::Sprite * _node_right = cocos2d::Sprite::create("Wall.png");
            _node_left->setAnchorPoint(cocos2d::Point(0,0));
            _weight = SIZE_WALL_WIDTH;
            _height = (_weight * _node_left->getContentSize().height)/_node_left->getContentSize().width;
            _background->setOffsetHeight(_height);
            _node_left->setScale(SIZE_WALL_WIDTH/_node_left->getContentSize().width);
            _node_right->setAnchorPoint(cocos2d::Point(0,0));
            _node_right->setScale(SIZE_WALL_WIDTH/_node_right->getContentSize().width);
            _background->addChild(_node_left, radomValueBetween(-1,1), cocos2d::Point(0,1),
                                  cocos2d::Point(0,i * _height));
            _background->addChild(_node_right,radomValueBetween(-1, 1), cocos2d::Point(0,1),
                                  cocos2d::Point(visibleSize.width - SIZE_WALL_WIDTH,i * _height));
            margin = _node_left->getContentSize().width*_node_left->getScale();

        }
    }
    
    //Event Tag Scence
    {
        cocos2d::EventListenerTouchOneByOne * _listener = cocos2d::EventListenerTouchOneByOne::create();
        _listener->onTouchBegan = CC_CALLBACK_2(HelloWorld::onTouchBegan, this);
        _listener->onTouchEnded = CC_CALLBACK_2(HelloWorld::onTouchEnded, this);
        _eventDispatcher->addEventListenerWithSceneGraphPriority(_listener, this);
    }
    this->addChild(_background,-1);
    _count_wait = 3;
    existBall = false;
    _isFlying = false;
    _isDead = false;
    b2Vec2 gravity = b2Vec2(0.0f, -9.8f);
    world = new b2World(gravity);
    world->SetContactListener(this);
    addWall(20 ,visibleSize.height ,0,(visibleSize.height / 2) ); //Trái
    addWall(20 ,visibleSize.height ,visibleSize.width,(visibleSize.height / 2) ); // Phải
    ninjaBound = Sprite::create("Ninja.png");
    ninjaBound->setScale(0.25);
    this->createGameScene();
    ninjaBound->setPosition(200, 200);
    this->addChild(ninjaBound, -1);
    _obstacle = *new Vector<Sprite*>(3);
    schedule(schedule_selector(HelloWorld::update),0.01);
    schedule(schedule_selector(HelloWorld::setObstacles), 0.8);
    return true;
}
void HelloWorld::createGameScene(){
    _obstacle.clear();
    startPoint = 0;
    jumpTimed = 1;
    ninja = SkeletonAnimation::createWithFile("skeleton.json", "skeleton.atlas", 0.25f);
    ninja->setAnimation(0, "Run on Wall", true);
    
    _isRunning = true;
    ninja->setPosition(margin+20, 200);
    ninja->setTag(1);
    ninja->setScaleX(-1);
    this->addChild(ninja, 0);
    bodyShape.m_radius = 50/SCALE_RATIO;
    fixtureDef.density=10;
    fixtureDef.friction=0.8;
    fixtureDef.restitution=0.6;
    fixtureDef.shape=&bodyShape;
    bodyDef.type = b2_dynamicBody;
    bodyDef.userData = ninja;
    bodyDef.position.Set(ninja->getPosition().x/SCALE_RATIO, ninja->getPosition().y/SCALE_RATIO);
}
void HelloWorld::gameOver(){
    auto closeItem = MenuItemImage::create(
                                           "CloseNormal.png",
                                           "CloseSelected.png",
                                           CC_CALLBACK_1(HelloWorld::menuCloseCallback, this));
    
    closeItem->setPosition(Vec2(visibleSize.width/2, visibleSize.height/2));
    
    // create menu, it's an autorelease object
    auto menu = Menu::create(closeItem, NULL);
    menu->setPosition(Vec2::ZERO);
    this->addChild(menu, 1);
}
void HelloWorld::update(float delta)
{
    ninjaBound->setPosition(ninja->getPosition());
    cocos2d::Point scroll = cocos2d::Point(0,10);
    _background->setPosition(_background->getPosition() - scroll);
    _background->updatePosition();
    //CCLOG("%d", a);
    for (int i = startPoint; i<_obstacle.size(); i++) {
        if (_obstacle.at(i) != NULL) {
            if (_obstacle.at(i)->getPositionY()<=-200) {
                startPoint += 1;
            }
            if (ninja->getBoundingBox().intersectsRect(_obstacle.at(i)->getBoundingBox())&&!_isDead) {
                if(_obstacle.at(i)->getTag() == OBSTACLES || _obstacle.at(i)->getTag() == DARTS){
                    bodyDef.position.Set(ninja->getPosition().x/SCALE_RATIO, ninja->getPosition().y/SCALE_RATIO);
                    body = world->CreateBody(&bodyDef);
                    body->SetGravityScale(8);
                    body->CreateFixture(&fixtureDef);
                    body->SetLinearVelocity(b2Vec2(0, 0));
                    ninja->setAnimation(0, "die", false);
                    _isDead = true;
                    _isFlying = false;
                    this->gameOver();
                    CCLOG("aaa");
                }
                if (_obstacle.at(i)->getTag() == CLOUDS && _isFlying && !_isClouding) {
                    jumpTimed = 0;
                    _isClouding = true;
                    world->DestroyBody(body);
                    bodyDef.position.Set(ninja->getPosition().x/SCALE_RATIO, ninja->getPosition().y/SCALE_RATIO);
                    body = world->CreateBody(&bodyDef);
                    body->SetGravityScale(8);
                    body->CreateFixture(&fixtureDef);
                    if(_isMovingLeft){
                        CCLOG("bbb");
                        body->SetLinearVelocity(b2Vec2(15, 25));
                        ninja->setScaleX(1);
                    }
                    if (!_isMovingLeft) {
                        body->SetLinearVelocity(b2Vec2(-15, 25));
                        ninja->setScaleX(-1);

                    }
                    
                }
            }
        }
    }
    int positionIterations = 10;
    int velocityIterations = 10;
    auto deltaTime = delta;
    
    world->Step(deltaTime, velocityIterations, positionIterations);
    
    if (existBall) {
        if(ninja->getPositionX()>visibleSize.width/2){
            world->DestroyBody(body);
            ninja->setPositionX(visibleSize.width - (margin +20));
            
        }
        if(ninja->getPositionX()<visibleSize.width/2){
            world->DestroyBody(body);
            ninja->setPositionX(margin +20);
            
        }
        ninja->setBonesToSetupPose();
        ninja->setAnimation(0, "Run on Wall", true);
        _isRunning = true;
        existBall = false;
    }
    if (_isFlying||_isDead) {
        ninja->setPosition(body->GetPosition().x*SCALE_RATIO, body->GetPosition().y*SCALE_RATIO);
    }
    if(_isRunning&&ninja->getPositionY()>=200){
        ninja->setPositionY(ninja->getPositionY() -2);
    }
    world->ClearForces();
    world->DrawDebugData();
}
void HelloWorld::addWall(float w, float h, float px, float py){
    b2PolygonShape floorShape;
    floorShape.SetAsBox(w/ SCALE_RATIO,h/ SCALE_RATIO);
    b2FixtureDef floorFixture;
    floorFixture.density=0;
    floorFixture.friction=10;
    floorFixture.restitution=0.5;
    floorFixture.shape=&floorShape;
    
    b2BodyDef floorBodyDef;
    floorBodyDef.position.Set(px/ SCALE_RATIO,py/ SCALE_RATIO);
    floorBodyDef.userData = wallRight;
    b2Body *floorBody = world->CreateBody(&floorBodyDef);
    floorBody->CreateFixture(&floorFixture);
}

float HelloWorld::radomValueBetween(float low,float height)
{
    return ((float)rand()/RAND_MAX) * (height - low) +low;
}
bool HelloWorld::onTouchBegan(cocos2d::Touch * touch, cocos2d::Event * event)
{
    if (!_isDead && !_isClouding && jumpTimed == 1) {
        bodyDef.position.Set(ninja->getPosition().x/SCALE_RATIO, ninja->getPosition().y/SCALE_RATIO);
        body = world->CreateBody(&bodyDef);
        body->SetGravityScale(10);
        body->CreateFixture(&fixtureDef);
        if (_isRunning) {
            if (ninja->getPositionX()<visibleSize.width/2) {
                body->SetLinearVelocity(b2Vec2(25, 30));
                ninja->setScaleX(1);
                ninja->setRotation(0);
                ninja->setAnimation(0, "Jump_wall", false);
                _isMovingLeft = false;
            }
            if (ninja->getPositionX()>visibleSize.width/2) {
                body->SetLinearVelocity(b2Vec2(-25, 30));
                ninja->setScaleX(-1);
                ninja->setRotation(0);
                ninja->setAnimation(0, "Jump_wall", false);
                _isMovingLeft = true;
            }
        }
        _isRunning = false;
        if (!_isRunning&&jumpTimed==1) {
            if (_isMovingLeft) {
                body->SetLinearVelocity(b2Vec2(-25, 25));
            }
            if (!_isMovingLeft) {
                body->SetLinearVelocity(b2Vec2(25, 25));
            }
        }

        _isFlying = true;
    }
    
    return true;
}
void HelloWorld::setObstacles(float delta)
{
    cocos2d::Sprite * bar_one = cocos2d::Sprite::create("Xa.png");
    cocos2d::Sprite * bar_two = cocos2d::Sprite::create("Xa.png");
    cocos2d::Sprite * thorns = cocos2d::Sprite::create("Chong.png");
    cocos2d::Sprite * cloud_one = cocos2d::Sprite::create("May.png");
    cocos2d::Sprite * cloud_two = cocos2d::Sprite::create("May.png");
    cocos2d::Sprite * darts = cocos2d::Sprite::create("Phi-tieu.png");
    cocos2d::Sprite * item_one = cocos2d::Sprite::create("ball.jpg");
    cocos2d::Sprite * item_two = cocos2d::Sprite::create("Item.png");
    bar_one->setAnchorPoint(cocos2d::Point(0,0));
    bar_two->setAnchorPoint(cocos2d::Point(0,0));
    thorns->setAnchorPoint(cocos2d::Point(0,0));
    cloud_one->setAnchorPoint(cocos2d::Point(0,0));
    cloud_two->setAnchorPoint(cocos2d::Point(0,0));
    darts->setAnchorPoint(cocos2d::Point(0,0));
    item_one->setAnchorPoint(cocos2d::Point(0,0));
    item_two->setAnchorPoint(cocos2d::Point(0,0));
    bar_one->setTag(OBSTACLES);
    bar_two->setTag(OBSTACLES);
    thorns->setTag(OBSTACLES);
    cloud_one->setTag(CLOUDS);
    cloud_two->setTag(CLOUDS);
    darts->setTag(DARTS);
    item_one->setTag(ITEMS);
    item_two->setTag(ITEMS);
    unsigned int type = arc4random() % 10;
    switch (type) {
        case 0:
            setPositionBarRight(bar_one);
            _obstacle.pushBack(bar_one);
            cloud_one->setPosition(Point(getContentSize().width/2,_count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
            this->addChild(cloud_one,0);
            _obstacle.pushBack(cloud_one);
            cloud_one->runAction(MoveTo::create(2.5*(cloud_one->getPositionY()/visibleSize.height), Point(cloud_one->getPositionX(), -200)));
            thorns->setPosition(Point(SIZE_WALL_WIDTH,_count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
            this->addChild(thorns,0);
            _obstacle.pushBack(thorns);
            thorns->runAction(MoveTo::create(2.5*(thorns->getPositionY()/visibleSize.height), Point(thorns->getPositionX(), -200)));
            if(arc4random()%100 > 75)
            {
                if(arc4random()%100 >= 80)
                {
                    item_two->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    this->addChild(item_two,0);
                    _obstacle.pushBack(item_two);
                    item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                }
                else
                {
                    item_one->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    this->addChild(item_one,0);
                    _obstacle.pushBack(item_one);
                    item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                }
            }
            break;
        case 1:
            setPositionBarLeft(bar_one);
            _obstacle.pushBack(bar_one);
            cloud_one->setPosition(cocos2d::Point(getContentSize().width/2 - cloud_one->getContentSize().width,_count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
            _obstacle.pushBack(cloud_one);
            this->addChild(cloud_one,0);
            cloud_one->runAction(MoveTo::create(2.5*(cloud_one->getPositionY()/visibleSize.height), Point(cloud_one->getPositionX(), -200)));
            thorns->setRotation(180);
            thorns->setPosition(cocos2d::Point(getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
            this->addChild(thorns,0);
            _obstacle.pushBack(thorns);
            thorns->runAction(MoveTo::create(2.5*(thorns->getPositionY()/visibleSize.height), Point(thorns->getPositionX(), -200)));
            if(arc4random()%100 > 75)
            {
                if(arc4random()%100 >= 80)
                {
                    item_two->setPosition(cocos2d::Point(getContentSize().width - item_two->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    this->addChild(item_two,0);
                    _obstacle.pushBack(item_two);
                    item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                }
                else
                {
                    item_one->setPosition(cocos2d::Point(getContentSize().width - item_one->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    this->addChild(item_one,0);
                    _obstacle.pushBack(item_one);
                    item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                }
            }
            break;
        case 2:
            setPositionBarRight(bar_one);
            _obstacle.pushBack(bar_one);
            thorns->setRotation(180);
            thorns->setPosition(cocos2d::Point(getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
            thorns->runAction(MoveTo::create(2.5*(thorns->getPositionY()/visibleSize.height), Point(thorns->getPositionX(), -200)));
            _obstacle.pushBack(thorns);
            this->addChild(thorns,0);
            darts->setPosition(cocos2d::Point(getContentSize().width/2 - darts->getContentSize().width,_count_wait * SIZE_LEVEL_HEIGHT - darts->getContentSize().height));
            darts->runAction(MoveTo::create(2.5*(darts->getPositionY()/visibleSize.height), Point(darts->getPositionX(), -200)));
            _obstacle.pushBack(darts);
            this->addChild(darts,0);
            if(arc4random()%100 > 75)
            {
                if(arc4random()%2 == 0)
                {
                    if(arc4random()%100 >= 80)
                    {
                        item_two->setPosition(cocos2d::Point(getContentSize().width - item_two->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
                        item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                        _obstacle.pushBack(item_two);
                        this->addChild(item_two,0);
                    }
                    else
                    {
                        item_one->setPosition(cocos2d::Point(getContentSize().width - item_one->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
                        item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                        _obstacle.pushBack(item_one);
                        this->addChild(item_one,0);
                    }
                }
                else
                {
                    if(arc4random()%100 >= 80)
                    {
                        item_two->setPosition(cocos2d::Point(getContentSize().width - item_one->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
                        item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                        _obstacle.pushBack(item_two);
                        this->addChild(item_two,0);
                    }
                    else
                    {
                        item_one->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
                        item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                        _obstacle.pushBack(item_one);
                        this->addChild(item_one,0);
                    }
                    
                }
            }
            break;
        case 3:
            setPositionBarLeft(bar_one);
            _obstacle.pushBack(bar_one);
            thorns->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
            thorns->runAction(MoveTo::create(2.5*(thorns->getPositionY()/visibleSize.height), Point(thorns->getPositionX(), -200)));
            _obstacle.pushBack(thorns);
            this->addChild(thorns,0);
            
            darts->setPosition(cocos2d::Point(getContentSize().width/2,_count_wait * SIZE_LEVEL_HEIGHT - darts->getContentSize().height));
            darts->runAction(MoveTo::create(2.5*(darts->getPositionY()/visibleSize.height), Point(darts->getPositionX(), -200)));
            _obstacle.pushBack(darts);
            this->addChild(darts,0);
            
            if(arc4random()%100 > 75)
            {
                if(arc4random()%2 == 0)
                {
                    if(arc4random()%100 >= 80)
                    {
                        item_two->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
                        item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                        _obstacle.pushBack(item_two);
                        this->addChild(item_two,0);
                    }
                    else
                    {
                        item_one->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
                        item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                        _obstacle.pushBack(item_one);
                        this->addChild(item_one,0);
                    }
                }
                else
                {
                    if(arc4random()%100 >= 80)
                    {
                        item_two->setPosition(cocos2d::Point(getContentSize().width - item_two->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
                        item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                        _obstacle.pushBack(item_two);
                        this->addChild(item_two,0);
                    }
                    else
                    {
                        item_one->setPosition(cocos2d::Point(getContentSize().width - item_one->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
                        item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                        _obstacle.pushBack(item_one);
                        this->addChild(item_one,0);
                    }

                }
            }
            break;
        case 4:
            setPositionBarLeft(bar_one);
            _obstacle.pushBack(bar_one);
            thorns->setPosition(cocos2d::Point(SIZE_WALL_WIDTH,
                                               _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
            thorns->runAction(MoveTo::create(2.5*(thorns->getPositionY()/visibleSize.height), Point(thorns->getPositionX(), -200)));
            _obstacle.pushBack(thorns);
            this->addChild(thorns,0);
            if(arc4random()%100 > 75)
            {
                if(arc4random()%100 >= 80)
                {
                    item_two->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                    _obstacle.pushBack(item_two);
                    this->addChild(item_two,0);
                }
                else
                {
                    item_one->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                    _obstacle.pushBack(item_one);
                    this->addChild(item_one,0);
                }
            }
            break;
        case 5:
            setPositionBarRight(bar_one);
            _obstacle.pushBack(bar_one);
            thorns->setRotation(180);
            thorns->setPosition(cocos2d::Point(getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
            thorns->runAction(MoveTo::create(2.5*(thorns->getPositionY()/visibleSize.height), Point(thorns->getPositionX(), -200)));
            _obstacle.pushBack(thorns);
            this->addChild(thorns,0);
            
            if(arc4random()%100 > 75)
            {
                if(arc4random()%100 >= 80)
                {
                    item_two->setPosition(cocos2d::Point(getContentSize().width - item_two->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                    _obstacle.pushBack(item_two);
                    this->addChild(item_two,0);
                }
                else
                {
                    item_one->setPosition(cocos2d::Point(getContentSize().width - item_one->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                    _obstacle.pushBack(item_one);
                    this->addChild(item_one,0);
                }
            }

            break;
        case 6:
            setPositionBarRight(bar_one);
            _obstacle.pushBack(bar_one);
            darts->setPosition(cocos2d::Point(getContentSize().width/2 - darts->getContentSize().width,_count_wait * SIZE_LEVEL_HEIGHT - darts->getContentSize().height));
            darts->runAction(MoveTo::create(2.5*(darts->getPositionY()/visibleSize.height), Point(darts->getPositionX(), -200)));
            _obstacle.pushBack(darts);
            this->addChild(darts,0);
            if(arc4random()%100 > 75)
            {
                if(arc4random()%2 == 0)
                {
                    if(arc4random()%100 >= 80)
                    {
                        item_two->setPosition(cocos2d::Point(getContentSize().width - item_two->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
                        item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                        _obstacle.pushBack(item_two);
                        this->addChild(item_two,0);
                    }
                    else
                    {
                        item_one->setPosition(cocos2d::Point(getContentSize().width - item_one->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
                        item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                        _obstacle.pushBack(item_one);
                        this->addChild(item_one,0);
                    }
                }
                else
                {
                    if(arc4random()%100 >= 80)
                    {
                        item_two->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
                        item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                        _obstacle.pushBack(item_two);
                        this->addChild(item_two,0);
                    }
                    else
                    {
                        item_one->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
                        item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                        _obstacle.pushBack(item_one);
                        this->addChild(item_one,0);
                    }
                    
                }
            }
            break;
        case 7:
            setPositionBarLeft(bar_one);
            _obstacle.pushBack(bar_one);
            darts->setPosition(cocos2d::Point(getContentSize().width/2,_count_wait * SIZE_LEVEL_HEIGHT - darts->getContentSize().height));
            darts->runAction(MoveTo::create(2.5*(darts->getPositionY()/visibleSize.height), Point(darts->getPositionX(), -200)));
            _obstacle.pushBack(darts);
            this->addChild(darts,0);
            if(arc4random()%100 > 75)
            {
                if(arc4random()%2 == 0)
                {
                    if(arc4random()%100 >= 80)
                    {
                        item_two->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
                        item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                        _obstacle.pushBack(item_two);
                        this->addChild(item_two,0);
                    }
                    else
                    {
                        item_one->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2 + thorns->getContentSize().height));
                        item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                        _obstacle.pushBack(item_one);
                        this->addChild(item_one,0);
                    }
                }
                else
                {
                    if(arc4random()%100 >= 80)
                    {
                        item_two->setPosition(cocos2d::Point(getContentSize().width - item_two->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
                        item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                        _obstacle.pushBack(item_two);
                        this->addChild(item_two,0);
                        
                    }
                    else
                    {
                        item_one->setPosition(cocos2d::Point(getContentSize().width - item_one->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
                        item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                        _obstacle.pushBack(item_one);
                        this->addChild(item_one,0);
                        
                    }
                    
                }
            }
            break;
        case 8:
            setPositionBarLeft(bar_one);
            _obstacle.pushBack(bar_one);
            cloud_one->setPosition(cocos2d::Point(getContentSize().width/2,
                                                  _count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
            cloud_one->runAction(MoveTo::create(2.5*(cloud_one->getPositionY()/visibleSize.height), Point(cloud_one->getPositionX(), -200)));
            _obstacle.pushBack(cloud_one);
            this->addChild(cloud_one,0);
            if(arc4random()%100 > 75)
            {
                if(arc4random()%100 >= 80)
                {
                    item_two->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                    _obstacle.pushBack(item_two);
                    this->addChild(item_two,0);
                }
                else
                {
                    item_one->setPosition(cocos2d::Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                    _obstacle.pushBack(item_one);
                    this->addChild(item_one,0);
                }
            }

            break;
        case 9:
            setPositionBarRight(bar_one);
            _obstacle.pushBack(bar_one);
            cloud_one->setPosition(cocos2d::Point(getContentSize().width/2 - cloud_one->getContentSize().width,_count_wait * SIZE_LEVEL_HEIGHT - SIZE_LEVEL_HEIGHT/2));
            cloud_one->runAction(MoveTo::create(2.5*(cloud_one->getPositionY()/visibleSize.height), Point(cloud_one->getPositionX(), -200)));
            _obstacle.pushBack(cloud_one);
            this->addChild(cloud_one,0);
            if(arc4random()%100 > 75)
            {
                if(arc4random()%100 >= 80)
                {
                    item_two->setPosition(cocos2d::Point(getContentSize().width - item_two->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    _obstacle.pushBack(item_two);
                    item_two->runAction(MoveTo::create(2.5*(item_two->getPositionY()/visibleSize.height), Point(item_two->getPositionX(), -200)));
                    this->addChild(item_two,0);
                }
                else
                {
                    item_one->setPosition(cocos2d::Point(getContentSize().width - item_one->getContentSize().width - SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
                    item_one->runAction(MoveTo::create(2.5*(item_one->getPositionY()/visibleSize.height), Point(item_one->getPositionX(), -200)));
                    _obstacle.pushBack(item_one);
                    this->addChild(item_one,0);
                }
            }

            break;
        default:
            
            break;
    }
    _count_wait++;
}
void HelloWorld::setPositionBarLeft(cocos2d::Sprite * bar)
{
    bar->setScaleX((getContentSize().width - 2 * SIZE_WALL_WIDTH - SIZE_SPACE)/bar->getContentSize().width);
    bar->setScaleY(SIZE_BAR_HEIGHT / bar->getContentSize().height);
    bar->setPosition(cocos2d::Point(SIZE_SPACE+SIZE_WALL_WIDTH,
                                    _count_wait * SIZE_LEVEL_HEIGHT));
    float a = (bar->getPositionY() +100)/visibleSize.height;
    bar->runAction(MoveTo::create(2.5*a, Point(bar->getPositionX(), -200)));
    this->addChild(bar,0);
}
void HelloWorld::setPositionBarRight(cocos2d::Sprite * bar)
{
    bar->setScaleX((getContentSize().width - 2 * SIZE_WALL_WIDTH - SIZE_SPACE)/bar->getContentSize().width);
    bar->setScaleY(SIZE_BAR_HEIGHT / bar->getContentSize().height);
    bar->setPosition(Point(SIZE_WALL_WIDTH, _count_wait * SIZE_LEVEL_HEIGHT));
    float a = (bar->getPositionY() +100)/visibleSize.height;
    bar->runAction(MoveTo::create(2.5*a, Point(bar->getPositionX(), -200)));
    this->addChild(bar,0);
}

void HelloWorld::onTouchEnded(cocos2d::Touch * touch, cocos2d::Event * event)
{

}
void HelloWorld::BeginContact(b2Contact *contact){
    b2Fixture* fixtureA = contact->GetFixtureA();
    b2Fixture* fixtureB = contact->GetFixtureB();
    b2Body* body1 = fixtureA->GetBody();
    b2Body* body2 = fixtureB->GetBody();
    auto a = (Sprite*)body2->GetUserData();
    auto b = (Sprite*)body1->GetUserData();
    if (a->getTag()&&b->getTag()) {
        if (((a->getTag() == 1 && b->getTag() == 2) || (a->getTag() == 2 && b->getTag() == 1))&&_isFlying) {
            if (ninja->getPositionX()>visibleSize.width/2&&body->GetLinearVelocity().x>0) {
                existBall = true;
                _isFlying = false;
                _isClouding = false;
                jumpTimed = 1;

            }
            if (ninja->getPositionX()<visibleSize.width/2&&body->GetLinearVelocity().x<0) {
                existBall = true;
                _isFlying = false;
                _isClouding = false;
                jumpTimed = 1;

            }
        }
    }
}
void HelloWorld::EndContact(b2Contact *contact){
    
}
void HelloWorld::menuCloseCallback(Ref* pSender)
{
    Director::getInstance()->replaceScene
    (TransitionZoomFlipX::create(0.5, this->createScene()));
}
