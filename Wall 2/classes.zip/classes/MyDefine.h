//
//  MyDefine.h
//  Wall
//
//  Created by Nguyen Van Cuong on 1/7/15.
//
//

#ifndef __Wall__MyDefine__
#define __Wall__MyDefine__

#include <iostream>
#define WAIT_THRONS 10
#define SIZE_SPACE 250
#define SIZE_BAR_HEIGHT 50
#define SIZE_WALL_WIDTH 50
#define OBSTACLES 1000
#define DARTS 1001
#define ITEMS 1003
#define CLOUDS 1002
#define SIZE_LEVEL_HEIGHT 600
#endif /* defined(__Wall__MyDefine__) */
