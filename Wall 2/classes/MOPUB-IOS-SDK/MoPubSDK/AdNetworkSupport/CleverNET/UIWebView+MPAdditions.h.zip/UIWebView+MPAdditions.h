

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UIWebView (MPAdditions)

- (void)mp_setScrollable:(BOOL)scrollable;

@end
